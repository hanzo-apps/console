"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[833],{30824:(e,r,o)=>{o.d(r,{rI:()=>h});var t=o(51863),a={viewBox:t.$r,content:t.D0},i={hanzo:a,lux:{viewBox:"0 0 100 100",content:'<path d="M50 85 L15 25 L85 25 Z"/>'},zoo:{viewBox:"0 0 1024 1024",colored:!0,content:'<defs><clipPath id="zooClip"><circle cx="512" cy="511" r="270"/></clipPath><clipPath id="zooGClip"><circle cx="513" cy="369" r="234"/></clipPath><clipPath id="zooRClip"><circle cx="365" cy="595" r="234"/></clipPath></defs><g clip-path="url(#zooClip)"><circle cx="513" cy="369" r="234" fill="#00A652"/><circle cx="365" cy="595" r="234" fill="#ED1C24"/><circle cx="643" cy="595" r="234" fill="#2E3192"/><g clip-path="url(#zooGClip)"><circle cx="365" cy="595" r="234" fill="#FCF006"/><circle cx="643" cy="595" r="234" fill="#01ACF1"/></g><g clip-path="url(#zooRClip)"><circle cx="643" cy="595" r="234" fill="#EA018E"/></g><g clip-path="url(#zooGClip)"><g clip-path="url(#zooRClip)"><circle cx="643" cy="595" r="234" fill="#FFFFFF"/></g></g></g>'},pars:{viewBox:"-120 -120 240 240",content:'<path d="M0,-100 L30,-60 L100,-40 L60,0 L100,40 L30,60 L0,100 L-30,60 L-100,40 L-60,0 L-100,-40 L-30,-60 Z" fill="none" stroke="currentColor" stroke-width="4" stroke-linejoin="round"/><path d="M0,-70 L22,-42 L70,-28 L42,0 L70,28 L22,42 L0,70 L-22,42 L-70,28 L-42,0 L-70,-28 L-22,-42 Z" fill="currentColor" fill-opacity="0.15" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle r="55" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.4"/><circle r="35" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.4"/><circle r="8" fill="currentColor"/>'},"7stars":a,yotoda:a},n={accent1:"#000000",surface1:"#FFFFFF",surface2:"#FAFAFA",neutral1:"#0A0A0A",neutral2:"rgba(10, 10, 10, 0.6)"},l={accent1:"#FFFFFF",surface1:"#000000",surface2:"#111111",neutral1:"#FAFAFA",neutral2:"rgba(250, 250, 250, 0.6)"},c=(e,r)=>`https://cdn.jsdelivr.net/npm/${e}@latest/${r}`,s={id:"hanzo",name:"Hanzo",title:"Hanzo AI",tagline:"Enterprise AI infrastructure and frontier models",legalName:"Hanzo AI Inc.",domain:"hanzo.ai",docsDomain:"docs.hanzo.ai",adminDomain:"hanzo.ai",accentColor:"#FFFFFF",theme:{light:n,dark:l},social:{twitter:"https://x.com/hanzoai",github:"https://github.com/hanzoai",discord:"https://discord.gg/hanzo",linkedin:"https://linkedin.com/company/hanzoai"},mark:i.hanzo,logoUrl:c("@hanzo/brand","assets/logo/logo.svg"),faviconUrl:c("@hanzo/brand","assets/logo/favicon.svg")},p={id:"lux",name:"Lux",title:"Lux Network",tagline:"High-performance, post-quantum blockchain infrastructure",legalName:"Lux Industries Inc.",domain:"lux.network",docsDomain:"docs.lux.network",adminDomain:"lux.network",accentColor:"#FFFFFF",theme:{light:n,dark:l},social:{twitter:"https://x.com/luxdefi",github:"https://github.com/luxfi",discord:"https://discord.gg/lux"},mark:i.lux,logoUrl:c("@luxfi/brand","assets/logo/logo.svg"),faviconUrl:c("@luxfi/brand","assets/logo/favicon.svg")},f={id:"zoo",name:"Zoo",title:"Zoo",tagline:"Open, decentralized AI & science research network",legalName:"Zoo Labs Foundation",domain:"zoo.ngo",docsDomain:"docs.zoo.ngo",adminDomain:"zoo.ngo",accentColor:"#01ACF1",theme:{light:{...n,accent1:"#01ACF1"},dark:{...l,accent1:"#01ACF1"}},social:{twitter:"https://x.com/zoo_labs",github:"https://github.com/zooai",discord:"https://discord.gg/zoo"},mark:i.zoo,logoUrl:c("@zooai/brand","assets/logo/logo.svg"),faviconUrl:c("@zooai/brand","assets/logo/logo.svg")},d={id:"pars",name:"Pars",title:"Pars Network",tagline:"A sovereign, verifiable identity layer for the Pars community",legalName:"Parsis Foundation",domain:"pars.network",docsDomain:"docs.pars.network",adminDomain:"pars.network",accentColor:"#caa24a",theme:{light:{...n,accent1:"#caa24a"},dark:{...l,accent1:"#caa24a"}},social:{twitter:"https://x.com/parsnetwork",github:"https://github.com/parsdao"},mark:i.pars,logoUrl:c("@parsdao/brand","assets/logo/logo.svg"),faviconUrl:c("@parsdao/brand","assets/logo/logo.svg")},u={id:"7stars",name:"7Stars",title:"7Stars",tagline:"Cloud, powered by Hanzo",legalName:"7Stars",domain:"7stars.dev",docsDomain:"docs.7stars.dev",adminDomain:"7stars.dev",accentColor:"#FFFFFF",theme:{light:n,dark:l},social:{},mark:i["7stars"],logoUrl:s.logoUrl,faviconUrl:s.faviconUrl},g={id:"yotoda",name:"Yotoda",title:"Yotoda",tagline:"Cloud, powered by Hanzo",legalName:"Yotoda",domain:"yotoda.tech",docsDomain:"docs.yotoda.tech",adminDomain:"yotoda.tech",accentColor:"#FFFFFF",theme:{light:n,dark:l},social:{},mark:i.yotoda,logoUrl:s.logoUrl,faviconUrl:s.faviconUrl},h={hanzo:s,lux:p,zoo:f,pars:d,"7stars":u,yotoda:g}},49542:(e,r,o)=>{o.d(r,{Ou:()=>s});let t='<svg role="img" aria-label="Lux" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">\n\x3c!-- 3-D pyramid tumble (symmetric ridge + specular rake) → hover: vertical-axis turn → press: squash. Pure CSS, no JS. Generated from the logo tuner — edit there, not here. --\x3e\n<defs>\n<linearGradient id="lxridge" x1="0" y1="0" x2="1" y2="0">\n<stop offset="0" stop-color="#6f6f80"/><stop offset=".5" stop-color="#6f6f80" stop-opacity="0"/><stop offset="1" stop-color="#6f6f80"/></linearGradient>\n<linearGradient id="lxsheen" x1="0" y1="0" x2="1" y2="0">\n<stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>\n<clipPath id="lxtri"><path d="M50 88 L17.09 31 L82.91 31 Z"/></clipPath>\n</defs>\n<style>\n.pyr{transform-box:view-box;transform-origin:50px 50px;opacity:0;animation:lxrise 1.07s cubic-bezier(.55,0,.3,1) forwards}\n@keyframes lxrise{0%{opacity:0;transform:perspective(340px) rotateX(9.63deg) translateY(8%) scale(.05)}30%{opacity:1}72%{transform:perspective(340px) rotateX(9.63deg) translateY(-1%) scale(1.05)}100%{opacity:1;transform:perspective(340px) rotateX(9.63deg) translateY(0) scale(1)}}\n.shade{opacity:0;animation:lxshade 1.07s cubic-bezier(.62,0,.18,1) forwards}\n@keyframes lxshade{0%{opacity:0}30%{opacity:.82}100%{opacity:.17}}\n.spec{opacity:0;transform:translateX(-70px) rotate(-29deg);transform-box:fill-box;transform-origin:center;animation:lxspec 1.07s cubic-bezier(.5,0,.2,1) forwards}\n@keyframes lxspec{0%{opacity:0;transform:translateX(-70px) rotate(-29deg)}42%{opacity:.85}100%{opacity:0;transform:translateX(70px) rotate(-29deg)}}\n@media (prefers-reduced-motion:reduce){.pyr,.shade,.spec{animation:none;transform:none;opacity:1}.pyr{transform:perspective(340px) rotateX(9.63deg)}.shade{opacity:.17}.spec{opacity:0}}\n\n/* interaction — pure CSS, no JS: hover = one graceful turn (returns to rest), press = squash */\n.lux-hov{transform-box:view-box;transform-origin:50px 50px}\n.lux-prs{transform-box:view-box;transform-origin:50px 50px;transition:transform .22s cubic-bezier(.22,1,.36,1)}\nsvg:hover .lux-hov{animation:luxTurn 1s cubic-bezier(.45,0,.2,1)}\nsvg:active .lux-prs{transform:scale(.95)}\n@keyframes luxTurn{0%{transform:perspective(340px) rotateY(0)}100%{transform:perspective(340px) rotateY(360deg)}}\n@media (prefers-reduced-motion:reduce){.lux-hov,.lux-prs{animation:none!important;transform:none!important}.pyr,.shade,.spec{animation:none;transform:none;opacity:1}.shade{opacity:.17}.spec{opacity:0}}\n</style>\n<g class="lux-hov"><g class="lux-prs">\n<g class="pyr">\n<path d="M50 88 L17.09 31 L82.91 31 Z" fill="#fff"/>\n<path class="shade" d="M50 88 L17.09 31 L82.91 31 Z" fill="url(#lxridge)"/>\n<g clip-path="url(#lxtri)"><rect class="spec" x="20" y="-12" width="26" height="124" fill="url(#lxsheen)"/></g>\n</g>\n</g></g>\n</svg>',a="M50 85 L15 25 L85 25 Z";function i(){return`<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <path d="${a}" fill="#ffffff"/>
  </svg>`}function n(){return`<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <path d="${a}" fill="none" stroke="black" stroke-width="2"/>
  </svg>`}function l(){return`<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <path d="${a}" fill="white"/>
  </svg>`}function c(e={}){let r=btoa(unescape(encodeURIComponent(function e(r={}){let{variant:o="color",format:a="svg"}=r;if("animated"===o)return"dataUrl"===a?p():"base64"===a?btoa(unescape(encodeURIComponent(t))):t;if("dataUrl"===a)return c({variant:o});if("base64"===a)return function(r={}){return btoa(unescape(encodeURIComponent(e({...r,format:"svg"}))))}({variant:o});switch(o){case"mono":return n();case"white":return l();default:return i()}}({...e,format:"svg"}))));return`data:image/svg+xml;base64,${r}`}function s(){return t}function p(){return"data:image/svg+xml;base64,"+btoa(unescape(encodeURIComponent(t)))}i(),n(),l(),c(),c({variant:"mono"}),c({variant:"white"}),p(),o(38587)},51756:(e,r,o)=>{o.d(r,{Ou:()=>s});let t='<svg role="img" aria-label="Zoo" viewBox="222 221 580 580" xmlns="http://www.w3.org/2000/svg">\n\x3c!-- Golden-ratio (phi) lotus bloom → exact prism → hover: one spin → press: squash. Pure CSS, no JS. Generated from the logo tuner — edit there, not here. --\x3e\n<defs>\n<clipPath id="oc"><circle cx="512" cy="511" r="270"/></clipPath>\n<clipPath id="gc"><circle cx="513" cy="369" r="234"/></clipPath>\n<clipPath id="rc"><circle cx="365" cy="595" r="234"/></clipPath>\n</defs>\n<style>.zg{transform-box:view-box;transform-origin:512px 511px;opacity:0;animation:zgk 0.62s cubic-bezier(.22,1,.36,1) 0.00s forwards}\n@keyframes zgk{0%{opacity:0;transform:rotate(-105deg) scale(0.62)}30%{opacity:.85}100%{opacity:1;transform:rotate(0deg) scale(1)}}\n.zb{transform-box:view-box;transform-origin:512px 511px;opacity:0;animation:zbk 1.00s cubic-bezier(.22,1,.36,1) 0.00s forwards}\n@keyframes zbk{0%{opacity:0;transform:rotate(-157.6deg) scale(0.62)}30%{opacity:.85}100%{opacity:1;transform:rotate(0deg) scale(1)}}\n.zh{transform-box:view-box;transform-origin:512px 511px;opacity:0;animation:zhk 1.62s cubic-bezier(.22,1,.36,1) 0.00s forwards}\n@keyframes zhk{0%{opacity:0;transform:rotate(-262.6deg) scale(0.62)}30%{opacity:.85}100%{opacity:1;transform:rotate(0deg) scale(1)}}\n/* interaction — pure CSS, no JS: hover = one graceful turn (returns to rest), press = squash */\n.zoo-hov{transform-box:view-box;transform-origin:512px 511px}\n.zoo-prs{transform-box:view-box;transform-origin:512px 511px;transition:transform .22s cubic-bezier(.22,1,.36,1)}\nsvg:hover .zoo-hov{animation:zooTurn 1.1s cubic-bezier(.45,0,.2,1)}\nsvg:active .zoo-prs{transform:scale(.95)}\n@keyframes zooTurn{to{transform:rotate(360deg)}}\n@media (prefers-reduced-motion:reduce){.zoo-hov,.zoo-prs{animation:none!important;transform:none!important}.zg,.zb,.zh{opacity:1;animation:none;transform:none}}\n</style>\n<g class="zoo-hov"><g class="zoo-prs">\n<g clip-path="url(#oc)">\n<circle cx="512" cy="511" r="270" fill="#ED1C24"/>\n<g class="zg"><circle cx="513" cy="369" r="234" fill="#00A652"/><g clip-path="url(#gc)"><circle cx="365" cy="595" r="234" fill="#FCF006"/></g></g>\n<g class="zb"><circle cx="643" cy="595" r="234" fill="#2E3192"/></g>\n<g class="zh"><g clip-path="url(#gc)"><circle cx="643" cy="595" r="234" fill="#01ACF1"/></g><g clip-path="url(#rc)"><circle cx="643" cy="595" r="234" fill="#EA018E"/></g><g clip-path="url(#gc)"><g clip-path="url(#rc)"><circle cx="643" cy="595" r="234" fill="#FFFFFF"/></g></g></g>\n</g>\n</g></g>\n</svg>',a={color:{outerRadius:270,outerX:512,outerY:511,circleRadius:234,greenX:513,greenY:369,redX:365,redY:595,blueX:643,blueY:595},mono:{outerRadius:283,outerX:508,outerY:510,strokeWidth:33,outerStrokeWidth:36}};function i(){let e=a.color;return`<svg width="1024" height="1024" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <clipPath id="outerCircleColor">
        <circle cx="${e.outerX}" cy="${e.outerY}" r="${e.outerRadius}"/>
      </clipPath>
      <clipPath id="greenClip">
        <circle cx="${e.greenX}" cy="${e.greenY}" r="${e.circleRadius}"/>
      </clipPath>
      <clipPath id="redClip">
        <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}"/>
      </clipPath>
      <clipPath id="blueClip">
        <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}"/>
      </clipPath>
    </defs>
    <g clip-path="url(#outerCircleColor)">
      <circle cx="${e.greenX}" cy="${e.greenY}" r="${e.circleRadius}" fill="#00A652"/>
      <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}" fill="#ED1C24"/>
      <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#2E3192"/>
      <g clip-path="url(#greenClip)">
        <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}" fill="#FCF006"/>
      </g>
      <g clip-path="url(#greenClip)">
        <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#01ACF1"/>
      </g>
      <g clip-path="url(#redClip)">
        <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#EA018E"/>
      </g>
      <g clip-path="url(#greenClip)">
        <g clip-path="url(#redClip)">
          <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#FFFFFF"/>
        </g>
      </g>
    </g>
  </svg>`}function n(){let e=a.color,r=a.mono;return`<svg width="1024" height="1024" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <clipPath id="outerCircleMono">
        <circle cx="${r.outerX}" cy="${r.outerY}" r="${r.outerRadius}"></circle>
      </clipPath>
    </defs>
    <g clip-path="url(#outerCircleMono)">
      <circle cx="${e.greenX}" cy="${e.greenY}" r="${e.circleRadius}" fill="none" stroke="black" stroke-width="${r.strokeWidth}"></circle>
      <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}" fill="none" stroke="black" stroke-width="${r.strokeWidth}"></circle>
      <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="none" stroke="black" stroke-width="${r.strokeWidth}"></circle>
      <circle cx="${r.outerX}" cy="${r.outerY}" r="${r.outerRadius-r.outerStrokeWidth/2}" fill="none" stroke="black" stroke-width="${r.outerStrokeWidth}"></circle>
    </g>
  </svg>`}function l(){return a.color,a.mono,n().replace(/stroke="black"/g,'stroke="white"')}function c(e={}){let{variant:r="color"}=e,o="";switch(r){case"mono":o=n();break;case"white":o=l();break;case"cropped":o=function(){let e=a.color,r=e.outerX-e.outerRadius-20,o=e.outerY-e.outerRadius-20,t=(e.outerRadius+20)*2;return`<svg width="${t}" height="${t}" viewBox="${r} ${o} ${t} ${t}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <clipPath id="outerCircleColor">
        <circle cx="${e.outerX}" cy="${e.outerY}" r="${e.outerRadius}"/>
      </clipPath>
      <clipPath id="greenClip">
        <circle cx="${e.greenX}" cy="${e.greenY}" r="${e.circleRadius}"/>
      </clipPath>
      <clipPath id="redClip">
        <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}"/>
      </clipPath>
      <clipPath id="blueClip">
        <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}"/>
      </clipPath>
    </defs>
    <g clip-path="url(#outerCircleColor)">
      <circle cx="${e.greenX}" cy="${e.greenY}" r="${e.circleRadius}" fill="#00A652"/>
      <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}" fill="#ED1C24"/>
      <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#2E3192"/>
      <g clip-path="url(#greenClip)">
        <circle cx="${e.redX}" cy="${e.redY}" r="${e.circleRadius}" fill="#FCF006"/>
      </g>
      <g clip-path="url(#greenClip)">
        <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#01ACF1"/>
      </g>
      <g clip-path="url(#redClip)">
        <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#EA018E"/>
      </g>
      <g clip-path="url(#greenClip)">
        <g clip-path="url(#redClip)">
          <circle cx="${e.blueX}" cy="${e.blueY}" r="${e.circleRadius}" fill="#FFFFFF"/>
        </g>
      </g>
    </g>
  </svg>`}();break;default:o=i()}let t=btoa(unescape(encodeURIComponent(o)));return`data:image/svg+xml;base64,${t}`}function s(){return t}i(),n(),l(),c(),c({variant:"mono"}),c({variant:"white"}),btoa(unescape(encodeURIComponent(t))),o(38587)},51863:(e,r,o)=>{o.d(r,{D0:()=>i,$r:()=>a,Ou:()=>f});let t='<svg role="img" aria-label="Hanzo" viewBox="0 0 67 67" xmlns="http://www.w3.org/2000/svg">\n\x3c!-- Origami fold-in → hover: one 3-D turn → press: squash. Pure CSS, no JS. Canonical 7-path shaded H. --\x3e\n\n<style>.o{fill:#fff;opacity:0;transform-box:fill-box;transform-origin:left center;animation:fold 0.42s cubic-bezier(.16,1,.3,1) forwards}\n.s{fill:#ddd}\n@keyframes fold{from{opacity:0;transform:perspective(320px) rotateY(90deg)}to{opacity:1;transform:none}}\n.o0{animation-delay:0.00s}.o1{animation-delay:0.06s}.o2{animation-delay:0.12s}.o3{animation-delay:0.18s}.o4{animation-delay:0.24s}\n/* interaction — pure CSS, no JS: hover = one graceful turn (returns to rest), press = squash */\n.hanzo-hov{transform-box:view-box;transform-origin:33.5px 33.5px}\n.hanzo-prs{transform-box:view-box;transform-origin:33.5px 33.5px;transition:transform .22s cubic-bezier(.22,1,.36,1)}\nsvg:hover .hanzo-hov{animation:hanzoTurn 0.85s cubic-bezier(.45,0,.2,1)}\nsvg:active .hanzo-prs{transform:scale(.92)}\n@keyframes hanzoTurn{0%{transform:perspective(300px) rotateY(0)}100%{transform:perspective(300px) rotateY(360deg)}}\n@media (prefers-reduced-motion:reduce){.hanzo-hov,.hanzo-prs{animation:none!important;transform:none!important}.o{opacity:1;animation:none;transform:none}}\n</style>\n<g class="hanzo-hov"><g class="hanzo-prs">\n<path class="o o0" d="M22.21 0H0V22.3184H22.21V0Z"/>\n<path class="o o1" d="M66.7198 0H44.5098V22.3184H66.7198V0Z"/>\n<path class="o o1 s" d="M66.6753 22.3185L44.5098 20.0822V22.3185H66.6753Z"/>\n<path class="o o2" d="M66.7038 22.3184H22.2534L0.0878906 44.6367H44.4634L66.7038 22.3184Z"/>\n<path class="o o3" d="M22.21 67V44.6369H0V67H22.21Z"/>\n<path class="o o3 s" d="M0 44.6369L22.21 46.8285V44.6369H0Z"/>\n<path class="o o4" d="M66.7198 67V44.6369H44.5098V67H66.7198Z"/>\n</g></g>\n</svg>',a="0 0 67 67",i='<path d="M22.21 67V44.6369H0V67H22.21Z"/><path class="shade" fill="#DDDDDD" d="M0 44.6369L22.21 46.8285V44.6369H0Z"/><path d="M66.7038 22.3184H22.2534L0.0878906 44.6367H44.4634L66.7038 22.3184Z"/><path d="M22.21 0H0V22.3184H22.21V0Z"/><path d="M66.7198 0H44.5098V22.3184H66.7198V0Z"/><path class="shade" fill="#DDDDDD" d="M66.6753 22.3185L44.5098 20.0822V22.3185H66.6753Z"/><path d="M66.7198 67V44.6369H44.5098V67H66.7198Z"/>';function n(){return`<svg viewBox="0 0 67 67" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.21 67V44.6369H0V67H22.21Z" fill="#ffffff"/>
    <path d="M0 44.6369L22.21 46.8285V44.6369H0Z" fill="#DDDDDD"/>
    <path d="M66.7038 22.3184H22.2534L0.0878906 44.6367H44.4634L66.7038 22.3184Z" fill="#ffffff"/>
    <path d="M22.21 0H0V22.3184H22.21V0Z" fill="#ffffff"/>
    <path d="M66.7198 0H44.5098V22.3184H66.7198V0Z" fill="#ffffff"/>
    <path d="M66.6753 22.3185L44.5098 20.0822V22.3185H66.6753Z" fill="#DDDDDD"/>
    <path d="M66.7198 67V44.6369H44.5098V67H66.7198Z" fill="#ffffff"/>
  </svg>`}function l(){return`<svg viewBox="0 0 67 67" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.21 67V44.6369H0V67H22.21Z" fill="#000000"/>
    <path d="M0 44.6369L22.21 46.8285V44.6369H0Z" fill="#222222"/>
    <path d="M66.7038 22.3184H22.2534L0.0878906 44.6367H44.4634L66.7038 22.3184Z" fill="#000000"/>
    <path d="M22.21 0H0V22.3184H22.21V0Z" fill="#000000"/>
    <path d="M66.7198 0H44.5098V22.3184H66.7198V0Z" fill="#000000"/>
    <path d="M66.6753 22.3185L44.5098 20.0822V22.3185H66.6753Z" fill="#222222"/>
    <path d="M66.7198 67V44.6369H44.5098V67H66.7198Z" fill="#000000"/>
  </svg>`}function c(){return`<svg viewBox="0 0 67 67" xmlns="http://www.w3.org/2000/svg">
    <path d="M22.21 67V44.6369H0V67H22.21Z" fill="#ffffff"/>
    <path d="M0 44.6369L22.21 46.8285V44.6369H0Z" fill="#DDDDDD"/>
    <path d="M66.7038 22.3184H22.2534L0.0878906 44.6367H44.4634L66.7038 22.3184Z" fill="#ffffff"/>
    <path d="M22.21 0H0V22.3184H22.21V0Z" fill="#ffffff"/>
    <path d="M66.7198 0H44.5098V22.3184H66.7198V0Z" fill="#ffffff"/>
    <path d="M66.6753 22.3185L44.5098 20.0822V22.3185H66.6753Z" fill="#DDDDDD"/>
    <path d="M66.7198 67V44.6369H44.5098V67H66.7198Z" fill="#ffffff"/>
  </svg>`}function s(){return`<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
  <rect width="64" height="64" rx="8" fill="#000000"/>
  <g transform="translate(8, 8) scale(0.716)">
    <path d="M22.21 67V44.6369H0V67H22.21Z" fill="#ffffff"/>
    <path d="M66.7038 22.3184H22.2534L0.0878906 44.6367H44.4634L66.7038 22.3184Z" fill="#ffffff"/>
    <path d="M22.21 0H0V22.3184H22.21V0Z" fill="#ffffff"/>
    <path d="M66.7198 0H44.5098V22.3184H66.7198V0Z" fill="#ffffff"/>
    <path d="M66.7198 67V44.6369H44.5098V67H66.7198Z" fill="#ffffff"/>
  </g>
</svg>`}function p(e={}){let{variant:r="color"}=e,o="";switch(r){case"mono":o=l();break;case"white":o=c();break;case"favicon":o=s();break;default:o=n()}let t=btoa(unescape(encodeURIComponent(o)));return`data:image/svg+xml;base64,${t}`}function f(){return t}n(),l(),c(),s(),p(),p({variant:"mono"}),p({variant:"white"}),p({variant:"favicon"}),btoa(unescape(encodeURIComponent(t))),o(38587)},62512:(e,r,o)=>{var t=o(73472);o.o(t,"notFound")&&o.d(r,{notFound:function(){return t.notFound}}),o.o(t,"usePathname")&&o.d(r,{usePathname:function(){return t.usePathname}}),o.o(t,"useRouter")&&o.d(r,{useRouter:function(){return t.useRouter}}),o.o(t,"useSearchParams")&&o.d(r,{useSearchParams:function(){return t.useSearchParams}})}}]);